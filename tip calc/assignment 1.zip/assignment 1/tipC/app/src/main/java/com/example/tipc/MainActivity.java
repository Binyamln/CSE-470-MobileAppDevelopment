package com.example.tipc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText billTotal;
    TextView tipText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        billTotal = findViewById(R.id.editTextTextPersonBill);

        tipText = findViewById(R.id.textView);
        Button tip18;
        tip18 = findViewById(R.id.but18);
        tip18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(billTotal.getText().toString().equals("")) return;
                double bill = Double.parseDouble(String.valueOf(billTotal.getText()));
                String tipamt = String.format("%.2f" , (bill * 0.18));
                String totalamt = String.format("%.2f" , (bill * 1.18));
                tipText.setText("Tip:  " + tipamt + "   Total Bill:  " + totalamt);

            }
        });
        Button tip20;
        tip20 = findViewById(R.id.but20);
        tip20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(billTotal.getText().toString().equals("")) return;
                double bill = Double.parseDouble(String.valueOf(billTotal.getText()));
                String tipamt = String.format("%.2f" , (bill * 0.20));
                String totalamt = String.format("%.2f" , (bill * 1.20));
                tipText.setText("Tip:  " + tipamt + "   Total Bill:  " + totalamt);            }

        });
        Button tip22;
        tip22 = findViewById(R.id.but22);
        tip22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(billTotal.getText().toString().equals("")) return;
                double bill = Double.parseDouble(String.valueOf(billTotal.getText()));
                String tipamt = String.format("%.2f" , (bill * 0.22));
                String totalamt = String.format("%.2f" , (bill * 1.22));
                tipText.setText("Tip:  " + tipamt + "   Total Bill:  " + totalamt);
            }

        });

    }

}